import Main from './live-search/main.js'
export default Main
