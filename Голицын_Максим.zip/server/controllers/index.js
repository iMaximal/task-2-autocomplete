const home = require('./home');
const cities = require('./cities');

module.exports = {
    home,
    cities
};
